window.config = {
   "model_": "AppConfig",
   "id": 1,
   "appName": "KIPP Columbus - Secure Browser",
   "version": "1.0",
   "homepage": "https://kippcolumbus.illuminatehc.com/login",
   "enableReloadBttn": false,
   "enableLogoutBttn": false,
   "sessionDataTimeoutTime": 60,
   "termsOfService": "Developed by Netdemics LLC",
   "kioskEnabled": true
};